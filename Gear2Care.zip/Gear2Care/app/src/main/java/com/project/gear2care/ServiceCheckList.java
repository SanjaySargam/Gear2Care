package com.project.gear2care;

public class ServiceCheckList {
    private String serviceName;

    public String getServiceName() {
        return serviceName;
    }


    public ServiceCheckList(String serviceName) {
        this.serviceName = serviceName;
    }
    public ServiceCheckList(){}

}
