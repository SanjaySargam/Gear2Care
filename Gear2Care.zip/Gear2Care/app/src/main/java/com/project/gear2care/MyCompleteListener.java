package com.project.gear2care;

public interface MyCompleteListener {
    void onSuccess();
    void onFailure();
}
